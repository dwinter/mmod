#' Modern Measures of Divergence
#'
#'
#' @docType package
#' @name mmod
#' @aliases package-mmod
NULL
