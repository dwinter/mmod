#' Produce bootstrap samples from each subpopulation of a genind object
#'
#' This function produces bootstrap samples from a genind object, with each
#' subpopulation resampled according to its size. Because there are many 
#' statistics that you may wish to calculte from these samples, this function
#' returns a list of genind objects representing bootsrap samples that can then
#' be futher processed (see examples).
#' 
#'
#' @param x genind object (from package adegenet)
#' @param nreps numeric number of bootstrap replicates to perform (default 1000)
#' @export
#' @examples
#'\dontrun{  
#' data(nancycats)
#' bs <- chao_bootstrap(nancycats)
#' bs_D <- summarise_bootstrap(bs, D_Jost)
#'}
#' @family resample
#' 
#'

chao_bootstrap <- function(x, nreps=1000){
  loc <- x@loc.fac
  pop_sizes <- table(pop(x))
  pop_n <- length(pop_sizes)
  #population allele frequencies
  m <- apply(x@tab,2, function(y) tapply(y, pop(x), mean, na.rm=TRUE) )
  per_pop <- function(i){
    t(do.call(rbind, tapply(m[i,], loc, function(p) rgenotypes(pop_sizes[i],2,p)) ))
  }
  
  one_rep <- function(){
    temp <- x
    temp@tab <- do.call(rbind, sapply(1:pop_n , per_pop, simplify=FALSE))/2
    return(temp)
  }
  
  return(replicate(nreps, one_rep()))
}
